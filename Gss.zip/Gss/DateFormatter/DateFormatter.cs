
    
       string[] formats = {"M/d/yyyy", "MM/dd/yyyy",
                            "d/M/yyyy", "dd/MM/yyyy",
                            "yyyy/M/d", "yyyy/MM/dd",
                            "M-d-yyyy", "MM-dd-yyyy",
                            "d-M-yyyy", "dd-MM-yyyy",
                            "yyyy-M-d", "yyyy-MM-dd",
                            "M.d.yyyy", "MM.dd.yyyy",
                            "d.M.yyyy", "dd.MM.yyyy",
                            "yyyy.M.d", "yyyy.MM.dd",
                            "M,d,yyyy", "MM,dd,yyyy",
                            "d,M,yyyy", "dd,MM,yyyy",
                            "yyyy,M,d", "yyyy,MM,dd",
                            "M d yyyy", "MM dd yyyy",
                            "d M yyyy", "dd MM yyyy",
                            "yyyy M d", "yyyy MM dd","dd/MM/yy"
                           };
	      
            foreach (string format in formats)
            {
                if (DateTime.TryParseExact(UserDate, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out Date))
                {
                    UserDate = Date.ToString(UserFormatOption);
                    Date = DateTime.Parse(UserDate);
                    Console.WriteLine(Date);
                    break;
                }

            }
            
         






          
     
